__all__ = ["kipro"]
__doc__="""
This module provides a client to the REST API for embedded (stand-alone) products made by AJA Video Systems, Inc.
"""
